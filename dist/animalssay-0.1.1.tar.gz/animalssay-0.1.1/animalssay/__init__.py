from .animals import (
    cat_says,
    dog_says,
    frog_says,
    fox_says,
    cow_says,
    pig_says,
    owl_says,
)
